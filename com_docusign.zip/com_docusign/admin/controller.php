<?php

/**
 * --------------------------------------------------------------------------------
 * Docusign for Joomla
 * --------------------------------------------------------------------------------
 * @package     Joomla
 * @subpackage  Docusign
 * @author      Robert Ngethe
 * @copyright   Copyright (c) 2020. All rights reserved.
 * @license     GNU/GPL license: http://www.gnu.org/licenses/gpl-2.0.html
 * --------------------------------------------------------------------------------
 *
 * */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 

class MiniorangeOAuthController extends JControllerLegacy
{
	/**
	 * The default view for the display method.
	 *
	 * @var string
	 * @since 12.2
	 */
	protected $default_view = 'accountsetup';
}