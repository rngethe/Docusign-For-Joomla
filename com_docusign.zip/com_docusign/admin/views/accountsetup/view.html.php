<?php

/**
 * --------------------------------------------------------------------------------
 * Docusign for Joomla
 * --------------------------------------------------------------------------------
 * @package     Joomla
 * @subpackage  Docusign
 * @author      Robert Ngethe
 * @copyright   Copyright (c) 2020. All rights reserved.
 * @license     GNU/GPL license: http://www.gnu.org/licenses/gpl-2.0.html
 * --------------------------------------------------------------------------------
 *
 * */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Account Setup View
 *
 * @since  0.0.1
 */
class miniorangeoauthViewAccountSetup extends JViewLegacy
{
    function display($tpl = null)
    {
        // Get data from the model
        $this->lists        = $this->get('List');
        //$this->pagination = $this->get('Pagination');

        // Check for errors.
        if (count($errors = $this->get('Errors')))
        {
            JFactory::getApplication()->enqueueMessage(500, implode('<br />', $errors));

            return false;
        }
        $this->setLayout('accountsetup');
        // Set the toolbar
        $this->addToolBar();

        // Display the template
        parent::display($tpl);
    }

    /**
     * Add the page title and toolbar.
     *
     * @return  void
     *
     * @since   1.6
     */
    protected function addToolBar()
    {
        JToolBarHelper::title(JText::_('com_docusign_PLUGIN_TITLE'),'mo_oauth_logo mo_oauth_icon');
    }

}