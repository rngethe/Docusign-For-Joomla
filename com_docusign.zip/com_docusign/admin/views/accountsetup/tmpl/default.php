<?php


/**
 * --------------------------------------------------------------------------------
 * Docusign for Joomla
 * --------------------------------------------------------------------------------
 * @package     Joomla
 * @subpackage  Docusign
 * @author      Robert Ngethe
 * @copyright   Copyright (c) 2020. All rights reserved.
 * @license     GNU/GPL license: http://www.gnu.org/licenses/gpl-2.0.html
 * --------------------------------------------------------------------------------
 *
 * */

// No direct access to this file
defined('_JEXEC') or die('Restricted Access');

JHtml::_('jquery.framework');
JHtml::stylesheet(JURI::base() . 'components/com_docusign/assets/css/docusign-toolbar.css', array(), true);
JHtml::stylesheet(JURI::base() . 'components/com_docusign/assets/css/bootstrap-tour-standalone.css', array(), true);
JHtml::script(JURI::base() . 'components/com_docusign/assets/js/bootstrap-tour-standalone.min.js');
JHtml::script(JURI::base() . 'components/com_docusign/assets/js/jeswanthscript.js');
JHtml::stylesheet('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array(), true);



$current_user = JFactory::getUser();
if (!JPluginHelper::isEnabled('system', 'docusign')) {
    ?>

    <div id="system-message-container">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <div class="alert alert-error">
            <h4 class="alert-heading">Warning!</h4>
            <div class="alert-message">
                <h4>This component requires System Plugin to be activated. Please activate the following plugin
                    to proceed further: System - Docusign for Joomla</h4>
                <h4>Steps to activate the plugins:</h4>
                <ul>
                    <li>In the top menu, click on Extensions and select Plugins.</li>
                    <li>Search for Docusign in the search box and press 'Search' to display the plugins.</li>
                    <li>Now enable the System plugin.</li>
                </ul>
            </div>
            </h4>
        </div>
    </div>
<?php } ?>

        <div>
            <div class="row-fluid">
                <div class="mo_oauth_table_layout_1">
                    <div class="mo_oauth_table_layout mo_oauth_large_container">
                        <?php configuration($OauthApp,$appLabel); ?>
                    </div>
                    </div>
                </div>

            </div>
        </div>



    <!--
        *End Of Tabs for accountsetup view.
        *Below are the UI for various sections of Account Creation.
    -->

<?php

function getAppDetails(){
    $db = JFactory::getDbo();
    $query = $db->getQuery(true);
    $query->select('*');
    $query->from($db->quoteName('#__docusign_config'));
    $query->where($db->quoteName('id') . " = 1");
    $db->setQuery($query);
    return $db->loadAssoc();}


function configuration($OauthApp,$appLabel)
{


    $attribute = getAppDetails();

    $mo_oauth_app = $appLabel;
    $custom_app = "";
    $client_id = "";
    $client_secret = "";
    $redirecturi = JURI::root();
    $email_attr = "";
    $first_name_attr = "";
    $isAppConfigured = FALSE;
    $mo_oauth_in_header = "checked=true";
    $mo_oauth_in_body   = "";
    if( isset($attribute['in_header_or_body']) && $attribute['in_header_or_body']=='both' ){
        $mo_oauth_in_header = "checked=true";
        $mo_oauth_in_body   = "checked=true";
    }
    else if(isset($attribute['in_header_or_body']) && $attribute['in_header_or_body']=='inBody'){
        $mo_oauth_in_header = "";
        $mo_oauth_in_body   = "checked=true";
    }


    if (isset($attribute['client_id'])) {
        $mo_oauth_app = empty($attribute['appname'])?$appLabel:$attribute['appname'];
        $custom_app = $attribute['custom_app'];
        $client_id = $attribute['client_id'];
        $client_secret = $attribute['client_secret'];
        $isAppConfigured = empty($client_id) || empty($client_secret) || empty($custom_app)?FALSE:TRUE;
        $app_scope = empty($attribute['app_scope'])?$OauthApp['scope']:$attribute['app_scope'];
        $authorize_endpoint = empty($attribute['authorize_endpoint'])?$OauthApp['authorize']:$attribute['authorize_endpoint'];
        $access_token_endpoint = empty($attribute['access_token_endpoint'])?$OauthApp['token']:$attribute['access_token_endpoint'];
        $user_info_endpoint = empty($attribute['user_info_endpoint'])?$OauthApp['userinfo']:$attribute['access_token_endpoint'];
        $email_attr = $attribute['email_attr'];
        $first_name_attr = $attribute['first_name_attr'];
    }

    ?>


    <form id="oauth_config_form" name="oauth_config_form" method="post"
          action="<?php echo JRoute::_('index.php?option=com_docusign&view=accountsetup&task=accountsetup.saveConfig'); ?>">
        <table class="mo_settings_table">

            <tr>
                <input type="hidden" name="mo_oauth_app_name" value="<?php echo $mo_oauth_app; ?>">
                <td style="width:20%;"><strong>Login URL:</strong></td>
                <td style="width:100%;"><input class="selected-text" id="loginUrl" type="text" style="width:80%;"
                                               readonly="true"
                                               value='<?php echo JURI::root() . '?morequest=oauthredirect&app_name=' . $mo_oauth_app; ?>'>
                    <i class="fa fa-fw fa-pull-right fa-lg fa-copy mo_copy copytooltip" ;
                       onclick="copyToClipboard('#loginUrl');" style="color:red" ;><span
                                class="copytooltiptext">Copied!</span> </i>

                </td>
            </tr>
            <tr>
                <td><strong><?php echo JText::_('COM_DOCUSIGN_CALLBACK_URL'); ?></strong></td>
                <td style="width:100%;"><input class="mo_table_textbox" id="callbackurl" type="text" style="width: 80%;"
                                               readonly="true" value='<?php echo $redirecturi; ?>'>
                    <i class="fa fa-fw fa-pull-right fa-lg fa-copy mo_copy copytooltip" ;
                       onclick="copyToClipboard('#callbackurl');" style="color:red" ;><span class="copytooltiptext">Copied!</span>
                    </i>

                </td>
            </tr>


            <tr id="mo_oauth_custom_app_name_div">
                <td><strong><font
                                color="#FF0000">*</font><?php echo JText::_('COM_DOCUSIGN_CUSTOM_APP_NAME'); ?>
                    </strong></td>
                <td><input class="mo_table_textbox" type="text" style="width: 80%;" id="mo_oauth_custom_app_name"
                           name="mo_oauth_custom_app_name" value='<?php echo $custom_app; ?>' required></td>
            </tr>
            <tr>
                <td><strong><font color="#FF0000">*</font><?php echo JText::_('COM_DOCUSIGN_CLIENT_ID'); ?>
                    </strong></td>
                <td><input class="mo_table_textbox" required="" type="text" style="width: 80%;"
                           name="mo_oauth_client_id" id="mo_oauth_client_id" value='<?php echo $client_id; ?>'></td>
            </tr>
            <tr>
                <td><strong><font color="#FF0000">*</font><?php echo JText::_('COM_DOCUSIGN_CLIENT_SECRET'); ?>
                    </strong></td>
                <td><input class="mo_table_textbox" type="text" style="width: 80%;"
                           id="mo_oauth_client_secret" name="mo_oauth_client_secret"
                           value='<?php echo $client_secret; ?>'></td>
            </tr>
            <tr>
                <td><strong><font color="#FF0000">*</font><?php echo JText::_('COM_DOCUSIGN_APP_SCOPE'); ?>
                    </strong></td>
                <td><input class="mo_table_textbox" required type="text" style="width: 80%;" id="mo_oauth_scope"
                           name="mo_oauth_scope" value='<?php echo $app_scope; ?>'></td>
            </tr>

            <tr id="mo_oauth_authorizeurl_div">
                <td><strong><font
                                color="#FF0000">*</font><?php echo JText::_('COM_DOCUSIGN_AUTHORIZE_ENDPOINT'); ?>
                    </strong></td>
                <td><input class="mo_table_textbox" type="text" style="width: 80%;"
                           id="mo_oauth_authorizeurl" name="mo_oauth_authorizeurl"
                           value='<?php echo $authorize_endpoint; ?>' required>
                    <i class="fa fa-fw fa-pull-right fa-lg fa-copy mo_copy copytooltip" ;
                       onclick="copyToClipboard('#mo_oauth_authorizeurl');" style="color:red" ;><span
                                class="copytooltiptext">Copied!</span> </i>
                </td>
            </tr>
            <tr id="mo_oauth_accesstokenurl_div">
                <td><strong><font color="#FF0000">*</font><?php echo JText::_('COM_DOCUSIGN_TOKEN_ENDPOINT'); ?>
                    </strong></td>
                <td><input class="mo_table_textbox" type="text" style="width: 80%;"
                           id="mo_oauth_accesstokenurl" name="mo_oauth_accesstokenurl"
                           value='<?php echo $access_token_endpoint; ?>' required>
                    <i class="fa fa-fw fa-pull-right fa-lg fa-copy mo_copy copytooltip" ;
                       onclick="copyToClipboard('#mo_oauth_accesstokenurl');" style="color:red" ;><span
                                class="copytooltiptext">Copied!</span> </i>
                </td>
            </tr>


            <?php if(!isset($OauthApp['type']) || $OauthApp['type']=='oauth'){
                ?>
                <tr id="mo_oauth_resourceownerdetailsurl_div">
                    <td><strong><font color="#FF0000">*</font><?php echo JText::_('COM_DOCUSIGN_INFO_ENDPOINT'); ?>
                        </strong></td>
                    <td><input class="mo_table_textbox" type="text" style="width: 80%;"
                               id="mo_oauth_resourceownerdetailsurl" name="mo_oauth_resourceownerdetailsurl"
                               value='<?php echo $user_info_endpoint; ?>' required>
                        <i class="fa fa-fw fa-pull-right fa-lg fa-copy mo_copy copytooltip" ;
                           onclick="copyToClipboard('#mo_oauth_resourceownerdetailsurl');" style="color:red" ;><span
                                    class="copytooltiptext">Copied!</span> </i>


                    </td>
                </tr>

                <?php
            }
            ?>
            <tr id="mo_oauth_set_credential_in_body_or_header">
                <td></td>
                <td>
                    <div style="padding:5px;"></div>
                    <input type="checkbox" style='vertical-align: -2px;' name="mo_oauth_in_header" value="1" <?php echo " ".$mo_oauth_in_header; ?>>&nbsp;Set client credentials in Header
                    <span style="padding:0px 0px 0px 8px;"></span>
                    <input type="checkbox" style='vertical-align: -2px;' class="mo_table_textbox" name="mo_oauth_body" value="1" <?php echo " ".$mo_oauth_in_body; ?> >&nbsp; Set client credentials in Body<div style="padding:5px;">
                    </div>
                </td>
            </tr>
            <tr style="height: 30px !important; background-color: #FFFFFF;">
                <td colspan="3"></td>
            </tr>
            <tr>
                <td>
                    <input type="hidden" name="moOauthAppName" value="<?php echo $appLabel; ?>">
                    <input type="submit" name="send_query" id="send_query"
                           value='<?php echo JText::_('COM_DOCUSIGN_SAVE_SETTINGS_BUTTON'); ?>'
                           style="margin-bottom:3%;" class="btn btn-medium btn-success"/></td>
                <td><input type="button" id="test_config_button"
                           title='<?php echo JText::_('COM_DOCUSIGN_TEST_CONFIGURATION_MESSAGE'); ?>'
                           style=" margin-left:30px; margin-right:65px;" class="btn btn-primary"
                           value='<?php echo JText::_('COM_DOCUSIGN_TEST_CONFIGURATION_BUTTON'); ?>'
                           onclick="testConfiguration()">
                    <a align="left"
                       href='index.php?option=com_docusign&view=accountsetup&task=accountsetup.clearConfig'
                       id="clear_config_button"
                       class="btn btn-danger"><?php echo JText::_('COM_DOCUSIGN_CLEAR_SETTINGS_BUTTON'); ?></td>
            </tr>
        </table>
    </form>

    <hr>
    <div id="mo_oauth_attr_mapping_div">
        <form id="oauth_mapping_form" name="oauth_config_form" method="post"
              action="<?php echo JRoute::_('index.php?option=com_docusign&view=accountsetup&task=accountsetup.saveMapping'); ?>">
            <div id="toggle2" class="panel_toggle">
                <h3><?php echo JText::_('COM_DOCUSIGN_ATTRIBUTE_MAPPING'); ?></h3>
                <h6><?php echo JText::_('COM_DOCUSIGN_ATTRIBUTE_MAPPING_MESSAGE'); ?></h6><br>
            </div>
            <table class="mo_mapping_table">
                <tr id="mo_oauth_email_attr_div">
                    <td><strong><font color="#FF0000">*</font><?php echo JText::_('COM_DOCUSIGN_EMAIL_ATTR'); ?>
                        </strong></td>
                    <td><input class="mo_table_textbox" required="" type="text" style="width:150%;"
                               id="mo_oauth_email_attr" name="mo_oauth_email_attr" value='<?php echo $email_attr; ?>'>
                    </td>
                </tr>
                <tr id="mo_oauth_first_name_attr_div">
                    <td><strong><font
                                    color="#FF0000">*</font><?php echo JText::_('COM_DOCUSIGN_FIRST_NAME_ATTR'); ?>
                        </strong></td>
                    <td><input class="mo_table_textbox" required="" type="text" style="width: 150%;"
                               id="mo_oauth_first_name_attr" name="mo_oauth_first_name_attr"
                               value='<?php echo $first_name_attr; ?>'></td>
                </tr>
                <tr style="height: 30px !important; background-color: #FFFFFF;">
                    <td colspan="3"></td>
                </tr>
                <tr>
                    <td><input type="submit" name="send_query" id="send_query"
                               value='<?php echo JText::_('COM_DOCUSIGN_SAVE_MAPPING_BUTTON'); ?>'
                               style="margin-bottom:3%;" class="btn btn-medium btn-success"/>
                </tr>
            </table>
        </form>
        <hr>
    </div>

    <?php
}
?>

