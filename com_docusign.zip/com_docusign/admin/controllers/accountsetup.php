<?php
/**
 * --------------------------------------------------------------------------------
 * Docusign for Joomla
 * --------------------------------------------------------------------------------
 * @package     Joomla
 * @subpackage  Docusign
 * @author      Robert Ngethe
 * @copyright   Copyright (c) 2020. All rights reserved.
 * @license     GNU/GPL license: http://www.gnu.org/licenses/gpl-2.0.html
 * --------------------------------------------------------------------------------
 *
 * */

/**
 * AccountSetup Controller
 *
 */

defined('_JEXEC') or die('Restricted access');

class miniorangeoauthControllerAccountSetup extends JControllerForm
{
	function __construct()
	{
		$this->view_list = 'accountsetup';
		parent::__construct();
	}

	
	function saveConfig() {		
		$db = JFactory::getDbo();		
		$query = $db->getQuery(true);
		 // Fields to update.
		$fields = array(
			$db->quoteName('appname') . ' = '.$db->quote($appname),
			$db->quoteName('custom_app') . ' = '.$db->quote($customappname),
			$db->quoteName('client_id') . ' = '.$db->quote(trim($clientid)),
			$db->quoteName('client_secret') . ' = '.$db->quote(trim($clientsecret)),
			$db->quoteName('app_scope') . ' = '.$db->quote($scope),
			$db->quoteName('authorize_endpoint') . ' = '.$db->quote(trim($authorizeurl)),
			$db->quoteName('access_token_endpoint') . ' = '.$db->quote(trim($accesstokenurl)),
			$db->quoteName('user_info_endpoint') . ' = '.$db->quote(trim($resourceownerdetailsurl)),
			$db->quoteName('in_header_or_body').'='.$db->quote($in_header_or_body)
		);

		// Conditions for which records should be updated.
		$conditions = array(
			$db->quoteName('id') . ' = 1'
			);
			
		$query->update($db->quoteName('#__docusign_config'))->set($fields)->where($conditions);
				$db->setQuery($query);
				$result = $db->execute();
		
			
		//Save configuration
				$message =  'Your configuration has been saved successfully.';
				$status = 'success';
				$this->setRedirect('index.php?option=com_docusign&view=accountsetup&moAuthAddApp='.$post['moOauthAppName'],$message );
	}
	
	function saveMapping(){
		$post=	JFactory::getApplication()->input->post->getArray();
		
		$email_attr = isset($post['mo_oauth_email_attr'])? $post['mo_oauth_email_attr'] : '';
		$first_name_attr = isset($post['mo_oauth_first_name_attr'])? $post['mo_oauth_first_name_attr'] : '';

		$db = JFactory::getDbo();		
		$query = $db->getQuery(true);
		 // Fields to update.
		$fields = array(
			$db->quoteName('email_attr') . ' = '.$db->quote($email_attr),
			$db->quoteName('first_name_attr') . ' = '.$db->quote($first_name_attr),
			);
	
		// Conditions for which records should be updated.
		$conditions = array(
			$db->quoteName('id') . ' = 1'
			);
			
		$query->update($db->quoteName('#__docusign_config'))->set($fields)->where($conditions);
				$db->setQuery($query);
				$result = $db->execute();		
		
		$message =  'Attribute Mapping saved successfully.';
		$this->setRedirect('index.php?option=com_docusign&view=accountsetup&tab-panel=configuration',$message );
	}
	
	function clearConfig(){
		$post=	JFactory::getApplication()->input->post->getArray(); 
		
		$clientid = "";
		$clientsecret = "";
		$scope = "";
		$appname = "";
		$customappname = "";
		$authorizeurl = "";
		$accesstokenurl = "";
		$resourceownerdetailsurl = "";
		$email_attr="";
		$first_name_attr="";
		
		$db = JFactory::getDbo();		
		$query = $db->getQuery(true);
		 // Fields to update.
		$fields = array(
			$db->quoteName('appname') . ' = '.$db->quote($appname),
			$db->quoteName('custom_app') . ' = '.$db->quote($customappname),
			$db->quoteName('client_id') . ' = '.$db->quote($clientid),
			$db->quoteName('client_secret') . ' = '.$db->quote($clientsecret),
			$db->quoteName('app_scope') . ' = '.$db->quote($scope),
			$db->quoteName('authorize_endpoint') . ' = '.$db->quote($authorizeurl),
			$db->quoteName('access_token_endpoint') . ' = '.$db->quote($accesstokenurl),
			$db->quoteName('user_info_endpoint') . ' = '.$db->quote($resourceownerdetailsurl),
			$db->quoteName('email_attr') . ' = '.$db->quote($email_attr),
			$db->quoteName('first_name_attr') . ' = '.$db->quote($first_name_attr),
			);
	
		// Conditions for which records should be updated.
		$conditions = array(
			$db->quoteName('id') . ' = 1'
			);
			
		$query->update($db->quoteName('#__docusign_config'))->set($fields)->where($conditions);
				$db->setQuery($query);
				$result = $db->execute();
	
		//Save configuration
				$message =  'Your configuration has been Reset successfully.';
				$this->setRedirect('index.php?option=com_docusign&view=accountsetup&tab-panel=configuration',$message );
	}
}
