
ALTER TABLE `#__docusign_config` ADD COLUMN IF NOT EXISTS `in_header_or_body` varchar(255) NOT NULL default 'both';
