<?php

/**
 * --------------------------------------------------------------------------------
 * Docusign for Joomla
 * --------------------------------------------------------------------------------
 * @package     Joomla
 * @subpackage  Docusign
 * @author      Robert Ngethe
 * @copyright   Copyright (c) 2020. All rights reserved.
 * @license     GNU/GPL license: http://www.gnu.org/licenses/gpl-2.0.html
 * --------------------------------------------------------------------------------
 *
 * */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.plugin.plugin');


class plgSystemMiniorangeoauth extends JPlugin
{

    public function onAfterInitialise()
    {
        $app = JFactory::getApplication();
        $post = $app->input->post->getArray();

        /*----------------------Oauth Flow-------------------------------------------*/


        $get = $app->input->get->getArray();
        $session = JFactory::getSession();
        /*----------------------Test Configuration Handling----------------------------*/
        if (isset($get['morequest']) and $get['morequest'] == 'testattrmappingconfig') {
            $mo_oauth_app_name = $get['app'];

            $app->redirect(JRoute::_(JURI::root() . '?morequest=oauthredirect&app_name=' . urlencode($mo_oauth_app_name) . '&test=true'));
        } 
        /*-------------------------OAuth SSO starts with this if-----------
        *            Opening of OAuth server dialog box
                     Step 1 of Oauth/OpenID flow
        */
        else if (isset($get['morequest']) and $get['morequest'] == 'oauthredirect') {

            $appname = $get['app_name'];

            if (isset($get['test']))
                setcookie("mo_oauth_test", true);
            else
                setcookie("mo_oauth_test", false);

            // save the referrer in cookie so that we can come back to origin after SSO
            if (isset($_SERVER['HTTP_REFERER']))
                $loginredirurl = $_SERVER['HTTP_REFERER'];

            if (!empty($loginredirurl)) {
                setcookie("returnurl", $loginredirurl);
            }

            // get Ouath configuration from database
            $appdata = $this->miniOauthFetchDb('#__docusign_config', array('custom_app'=>$appname));
            if(is_null($appdata))
                $appdata = $this->miniOauthFetchDb('#__docusign_config', array('appname'=>$appname));
            $state = base64_encode($appname);
            $authorizationUrl = $appdata['authorize_endpoint'];
            if (strpos($authorizationUrl, '?') !== false)
                $authorizationUrl = $authorizationUrl . "&client_id=" . $appdata['client_id'] . "&scope=" . $appdata['app_scope'] . "&redirect_uri=" . JURI::root() . "&response_type=code&state=" . $state;
            else
                $authorizationUrl = $authorizationUrl . "?client_id=" . $appdata['client_id'] . "&scope=" . $appdata['app_scope'] . "&redirect_uri=" . JURI::root() . "&response_type=code&state=" . $state;

            if (session_id() == '' || !isset($session))
                session_start();
            $session->set('oauth2state', $state);
            $session->set('appname', $appname);
            if(empty($appdata['client_id']) || empty($appdata['app_scope'])){
                echo "<center><h3 style='color:indianred;border:1px dotted black;'>System Error! You need to fill correct details to achieve the test.</h3></center>";
                exit;
            }
            header('Location: ' . $authorizationUrl);
            exit;
        } 
        
        /*
        *   Step 2 of OAuth Flow starts. We got the code
        *
        */

        else if (isset($get['code'])) {

            if (session_id() == '' || !isset($session))
                session_start();

            try {
                // get the app name from session or by decoding state
                $currentappname = "";
                $session_var = $session->get('appname');
                if (isset($session_var) && !empty($session_var))
                    $currentappname = $session->get('appname');
                else if (isset($get['state']) && !empty($get['state']))
                    $currentappname = base64_decode($get['state']);

                if (empty($currentappname)) {
                    exit('No request found for this application.');
                }
                // get OAuth configuration
                $appname = $session->get('appname');
                $name_attr = "";
                $email_attr = "";

                $appdata = $this->miniOauthFetchDb('#__docusign_config', array('custom_app'=>$appname));
                if(is_null($appdata))
                    $appdata = $this->miniOauthFetchDb('#__docusign_config', array('appname'=>$appname));

                $currentapp = $appdata;

                if (isset($appdata['email_attr']))
                    $email_attr = $appdata['email_attr'];
                if (isset($appdata['first_name_attr']))
                    $name_attr = $appdata['first_name_attr'];

                if (!$currentapp)
                    exit('Application not configured.');

                $authBase = JPATH_BASE . DIRECTORY_SEPARATOR . 'administrator' . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_docusign';
                include_once $authBase . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'request.php';

                $mo_oauth_handler = new Mo_OAuth_Hanlder();

                /*
                 * make a back channel request for access token
                 * we may also get an ID token in openid flow
                 *
                 * */
                list($accessToken,$idToken) = $mo_oauth_handler->getAccessToken
                ($currentapp['access_token_endpoint'], 'authorization_code',
                    $currentapp['client_id'], $currentapp['client_secret'], $get['code'], JURI::root(),$currentapp['in_header_or_body']);
                $mo_oauth_handler->printError();
                /*
                *
                * if access token is valid then call userInfo endpoint to get user info or resource  owner details or extract from Id-token
                */

                $resourceownerdetailsurl = $currentapp['user_info_endpoint'];
                if (substr($resourceownerdetailsurl, -1) == "=") {
                    $resourceownerdetailsurl .= $accessToken;
                }
                $resourceOwner = $mo_oauth_handler->getResourceOwner($resourceownerdetailsurl, $accessToken,$idToken);
                $mo_oauth_handler->printError();
                list($email,$name)=$this->getEmailAndName($resourceOwner,$email_attr,$name_attr);
                $checkUser = $this->get_user_from_joomla($email);
                //efficiency of the plugin

            } catch (Exception $e) {

                exit($e->getMessage());

            }

        }

    }



    function testattrmappingconfig($nestedprefix, $resourceOwnerDetails)
    {

        foreach ($resourceOwnerDetails as $key => $resource) {
            if (is_array($resource) || is_object($resource)) {
                if (!empty($nestedprefix))
                    $nestedprefix .= ".";
                $this->testattrmappingconfig($nestedprefix . $key, $resource);
            } else {
                echo "<tr><td>";
                if (!empty($nestedprefix))
                    echo $nestedprefix . ".";
                echo $key . "</td><td>" . $resource . "</td></tr>";
            }
        }
    }

    function getnestedattribute($resource, $key)
    {
        //echo $key." : ";print_r($resource); echo "<br>";
        if (empty($key))
            return "";

        $keys = explode(".", $key);
        if (sizeof($keys) > 1) {
            $current_key = $keys[0];
            if (isset($resource[$current_key]))
                return $this->getnestedattribute($resource[$current_key], str_replace($current_key . ".", "", $key));
        } else {
            $current_key = $keys[0];
            if (isset($resource[$current_key]))
                return $resource[$current_key];
        }
    }

    function get_user_from_joomla($email)
    {
        //Check if email exist in database
        $db = JFactory::getDBO();
        $query = $db->getQuery(true)
            ->select('id')
            ->from('#__users')
            ->where('email=' . $db->quote($email));
        $db->setQuery($query);
        $checkUser = $db->loadObject();
        return $checkUser;
    }


    function updateCurrentUserName($id, $name)
    {
        if (empty($name)) {
            return;
        }
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $fields = array(
            $db->quoteName('name') . ' = ' . $db->quote($name),
        );
        $conditions = array(
            $db->quoteName('id') . ' = ' . $db->quote($id),
        );
        $query->update($db->quoteName('#__users'))->set($fields)->where($conditions);

        $db->setQuery($query);

        $result = $db->execute();
    }

    function updateUsernameToSessionId($userID, $username, $sessionId)
    {


        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $fields = array(
            $db->quoteName('username') . ' = ' . $db->quote($username),
            $db->quoteName('guest') . ' = ' . $db->quote('0'),
            $db->quoteName('userid') . ' = ' . $db->quote($userID),
        );

        $conditions = array(
            $db->quoteName('session_id') . ' = ' . $db->quote($sessionId),
        );

        $query->update($db->quoteName('#__session'))->set($fields)->where($conditions);
        $db->setQuery($query);
        $result = $db->execute();
    }


    function RegisterCurrentUser($name, $username, $email)
    {
        $app = JFactory::getApplication();
        $default_group = 2;
        $data['name'] = (isset($name) && ($name != "")) ? $name : $username;
        $data['username'] = $username;
        $data['email'] = $data['email1'] = $data['email2'] = JStringPunycode::emailToPunycode($email);
        $data['password'] = $data['password1'] = $data['password2'] = JUserHelper::genRandomPassword();
        $data['activation'] = '0';
        $data['block'] = '0';


        $data['groups'][] = $default_group;

        // Get the model and validate the data.
        jimport('joomla.application.component.model');

        if (!defined('JPATH_COMPONENT')) {
            define('JPATH_COMPONENT', JPATH_BASE . '/components/');
        }


        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select('*');
        $query->from($db->quoteName('#__docusign_config'));
        $query->where($db->quoteName('id') . " = 1");
        $db->setQuery($query);
        $result = $db->loadAssoc();


        $usrlim = $result['userslim'] + 1;
        ////////////////////////////////////////


        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $fields = array(
            $db->quoteName('userslim') . ' = ' . $db->quote($usrlim),
        );
        $conditions = array(
            $db->quoteName('id') . ' = 1'
        );
        $query->update($db->quoteName('#__docusign_config'))->set($fields)->where($conditions);

        $db->setQuery($query);

        $result = $db->execute();


        $user = new JUser;
        //Write to database
        if (!$user->bind($data)) {
            throw new Exception("Could not bind data. Error: " . $user->getError());
        }
        if (!$user->save()) {
            echo 'Could Not Save User Details ' . $user->getError();
            exit;
        }

        $checkUser = $this->get_user_from_joomla($email);
        if ($checkUser) {
            $user = JUser::getInstance($checkUser->id);

            $session = JFactory::getSession(); #Get current session vars
            // Register the needed session variables
            $session->set('user', $user);

            $app->checkSession();
            $sessionId = $session->getId();
            $this->updateUsernameToSessionId($user->id, $user->username, $sessionId);

            $user->setLastVisit();

            $db = JFactory::getDbo();
            $query = $db->getQuery(true);
            $query->select('*');
            $query->from($db->quoteName('#__docusign_config'));
            $query->where($db->quoteName('id') . " = 1");
            $db->setQuery($query);
            $result = $db->loadAssoc();

            if ($result['userslim'] < 25)
                $blkatocr = 0;
            else
                $blkatocr = 1;


            if ($blkatocr) {

                echo "Please contact your administrator for login.";
                exit;

            }


            $returnurl = JFactory::getApplication()->input->cookie->getArray();
            if (isset($returnurl['returnurl'])) {
                $redirectloginuri = $returnurl['returnurl'];
            } else {

                $redirectloginuri = JURI::root() . 'index.php?';
            }

            $app->redirect(JURI::root() . 'index.php?');
        }

    }
    function miniOauthFetchDb($tableName,$condition,$method='loadAssoc',$columns='*'){
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $columns = is_array($columns)?$db->quoteName($columns):$columns;
        $query->select($columns);
        $query->from($db->quoteName($tableName));

        foreach ($condition as $key=>$value)
            $query->where($db->quoteName($key) . " = " . $db->quote($value));

        $db->setQuery($query);
        if ($method=='loadColumn')
            return $db->loadColumn();
        else if($method == 'loadObjectList')
            return $db->loadObjectList();
        else if($method== 'loadResult')
            return $db->loadResult();
        else if($method == 'loadRow')
            return $db->loadRow();
        else
            return $db->loadAssoc();
    }
    function miniOauthUpdateDb($tableName,$fields,$conditions){
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        // Fields to update.
        $sanFields=array();
        foreach ($fields as $key=>$value){
            array_push($sanFields,$db->quoteName($key) . ' = ' . $db->quote($value));
        }
        // Conditions for which records should be updated.
        $sanConditions=array();
        foreach ($conditions as $key=>$value){
            array_push($sanConditions,$db->quoteName($key) . ' = ' . $db->quote($value));
        }
        $query->update($db->quoteName($tableName))->set($sanFields)->where($sanConditions);
        $db->setQuery($query);
        $db->execute();
    }

}
